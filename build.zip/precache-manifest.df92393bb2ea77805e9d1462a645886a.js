self.__precacheManifest = [
  {
    "revision": "e4ad9be52c9e11b4be3b",
    "url": "/TextUtils-reactjs/static/css/main.ff4c53e3.chunk.css"
  },
  {
    "revision": "e4ad9be52c9e11b4be3b",
    "url": "/TextUtils-reactjs/static/js/main.e4ad9be5.chunk.js"
  },
  {
    "revision": "0d630a3e1f21db7817dc",
    "url": "/TextUtils-reactjs/static/js/1.0d630a3e.chunk.js"
  },
  {
    "revision": "bb2f723801df419e30e0",
    "url": "/TextUtils-reactjs/static/js/2.bb2f7238.chunk.js"
  },
  {
    "revision": "50d7b56aef6a7d5c0fe5",
    "url": "/TextUtils-reactjs/static/js/runtime~main.50d7b56a.js"
  },
  {
    "revision": "d7822b718345bc5c1e3628a981d2e479",
    "url": "/TextUtils-reactjs/index.html"
  }
];